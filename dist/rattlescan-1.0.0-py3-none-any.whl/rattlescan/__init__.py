"""Rattlescan - Forensic metadata analysis and secure file cleaning tool for CLi environments."""
__version__ = "1.0.0"